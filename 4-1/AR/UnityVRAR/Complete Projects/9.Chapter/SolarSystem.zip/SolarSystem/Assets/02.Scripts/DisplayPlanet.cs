﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisplayPlanet : MonoBehaviour {

    private Transform tr;
    private Ray ray;
    private RaycastHit hit;

	// Use this for initialization
	void Start () {
        tr = GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Input.GetMouseButtonDown(0)
            && Physics.Raycast(ray, out hit, Mathf.Infinity, 1 << 8))
        {
            Debug.Log("Hit");
            var hitParentObj = hit.collider.transform.parent;
            hitParentObj.GetComponentInChildren<Canvas>(true).enabled = true;;

        }
	}
}
