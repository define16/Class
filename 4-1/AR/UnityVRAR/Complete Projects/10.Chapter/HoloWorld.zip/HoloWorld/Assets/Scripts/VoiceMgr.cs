﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
//보이스 명령을 위해 선언해야 하는 네임스페이스
using UnityEngine.Windows.Speech;


public class VoiceMgr : MonoBehaviour {

    //보이스 명령을 인식하는 클래스
    private KeywordRecognizer kr;

    //명령어에 따라 호출할 메소드를 연결할 델리게이트 선언
    private delegate void KeywordAction(PhraseRecognizedEventArgs args);

    //인식할 명령어와 호출할 메소드들을 저장할 딕셔너리
    private Dictionary<string, KeywordAction> keywordCollection;

	void Start () {
        //딕셔너리 생성
        keywordCollection = new Dictionary<string, KeywordAction>();

        //보이스 명령어 및 메소드 등록
        keywordCollection.Add("yellow", ChangeYellow);
        keywordCollection.Add("blue", ChangeBlue);

        //보이스 명령인식 클래스에 명령어 등록
        kr = new KeywordRecognizer(keywordCollection.Keys.ToArray());

        //명령어 파싱이 완료된 후 호출할 메소드 연결
        kr.OnPhraseRecognized += kr_Recognized;

        //보이스 명령어 인식 동작시작
        kr.Start();
	}
	
    //명령어 파싱종료 후 호출되는 메소드
    void kr_Recognized(PhraseRecognizedEventArgs args)
    {
        KeywordAction kAction;
        //파싱으로 넘어온 텍스트로 호출할 메소드 추출
        if (keywordCollection.TryGetValue(args.text, out kAction))
        {
            //메소드 호출
            kAction.Invoke(args);
        }
    }

    //"yellow" 키워드에 반응할 메소드
    void ChangeYellow(PhraseRecognizedEventArgs args)
    { 
        if (ReticleMgr.focusedObj != null)
        {
            var obj = ReticleMgr.focusedObj;
            obj.GetComponent<Renderer>().material.color = Color.yellow;
        }
    }

    //"blue" 키워드에 반응할 메소드
    void ChangeBlue(PhraseRecognizedEventArgs args)
    {
        if (ReticleMgr.focusedObj != null)
        {
            var obj = ReticleMgr.focusedObj;
            obj.GetComponent<Renderer>().material.color = Color.blue;
        }      
    }
}
