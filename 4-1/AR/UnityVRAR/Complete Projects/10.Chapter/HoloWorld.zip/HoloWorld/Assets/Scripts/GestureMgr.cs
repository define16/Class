﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//홀로렌즈용 Input 관련 기능을 사용하기 위해 선언
using UnityEngine.VR.WSA.Input;

public class GestureMgr : MonoBehaviour {
    //제스처의 이벤트를 받기 위해 선언
    private GestureRecognizer recognizer;

    void Awake () 
    {
        recognizer = new GestureRecognizer();
        //에어탭 이벤트가 발생했을때 실행할 로직 정의
        recognizer.TappedEvent += (source, tapCount, headRay) =>
        {
            if(ReticleMgr.focusedObj != null)
            {
                    //레티클로 응시하고 있는 게임오브젝트에 메시지 전달
                    ReticleMgr.focusedObj.SendMessage("OnTapped", SendMessageOptions.DontRequireReceiver);
            }
            
            RaycastHit hit;
            if(Physics.Raycast(transform.position, transform.forward, out hit, 10.0f))
            {
                var obj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                obj.transform.localScale = Vector3.one * 0.05f;
                obj.AddComponent<Rigidbody>();
                obj.transform.position = hit.point;
            }
                    
        };

        //이벤트 감지를 시작
        recognizer.StartCapturingGestures();
    }

    void Update () 
    {
        GameObject prevObject = ReticleMgr.focusedObj;

        //계속 같은 게임오브젝트를 응시하지 않을때 제스처 초기화
        if (ReticleMgr.focusedObj != prevObject)
        {
            recognizer.CancelGestures();
            recognizer.StartCapturingGestures();
        }
    }
}
