﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCube : MonoBehaviour {

    private bool isBlue = false;

	void Update () {
        transform.Rotate(Vector3.up * Time.deltaTime * 50.0f);		
	}

    void OnTapped()
    {
        isBlue = !isBlue;
        GetComponent<Renderer>().material.color = isBlue ? Color.blue : Color.yellow;
    }
}
