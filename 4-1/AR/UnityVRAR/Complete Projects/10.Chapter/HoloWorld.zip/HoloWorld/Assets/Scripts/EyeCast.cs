﻿using UnityEngine;

public class EyeCast : MonoBehaviour {

    private int spatialMeshLayer;

    void Start () {
        spatialMeshLayer = 1 << LayerMask.NameToLayer("SpatialMesh");
    }

    void Update () {
        RaycastHit hit;
        if (Input.GetMouseButtonDown(0) && Physics.Raycast(transform.position, transform.forward, out hit, 100.0f, spatialMeshLayer))
        {
            var obj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            obj.transform.localScale = Vector3.one * 0.05f;
            obj.AddComponent<Rigidbody>();
            obj.transform.position = hit.point;
        }
    }
}