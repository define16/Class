﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportController : MonoBehaviour {
    //SteamVR_TrackedObject를 저장할 변수
    private SteamVR_TrackedObject trackedObj;
    //SteamVR_TrackedController를 저장할 변수
    private SteamVR_TrackedController trackedCtrl;

    //SteamVR_Controller.Input 클래스의 접근성을 위한 프로퍼티 설정
    private SteamVR_Controller.Device controller
    {
        get
        { 
            return SteamVR_Controller.Input((int)trackedObj.index);
        }
    }

    //Line Renderer 컴포넌트를 저장할 변수
    private LineRenderer laser;

    private RaycastHit hit;
    private int floorLayer;

    private Transform tr;
    private Transform playerTr;

    void Awake () 
    {
        //컨트롤러에 포함된 SteamVR_TrackedObject 스크립트 저장
        trackedObj = GetComponent<SteamVR_TrackedObject>();
        //컨트롤러에 포함된 SteamVR_TrackedController 스크립트 저장
        trackedCtrl = GetComponent<SteamVR_TrackedController>();

        //Line Renderer 컴포넌트 추출
        laser = GetComponent<LineRenderer>();
        laser.enabled = false;

        //컨트롤러의 Transform 컴포넌트 추출
        tr = GetComponent<Transform>();
        //CameraRig 게임오브젝트의 Transform 컴포넌트 추출
        playerTr = GameObject.Find("[CameraRig]").GetComponent<Transform>();
        //바닥의 레이어를 미리 계산후 변수에 저장
        floorLayer = 1<<LayerMask.NameToLayer("FLOOR");
    }

    void OnEnable()
    {
        //트랙 패드를 터치했을때 발생하는 이벤트 연결
        trackedCtrl.PadTouched += TrackPad;
        //트랙 패드의 터치가 해제됬을때 발생하는 이벤트 연결
        trackedCtrl.PadUntouched += ReleaseTrackPad;
        //트랙 패드를 클릭했을때 발생하는 이벤트 연결
        trackedCtrl.PadClicked += RayCastAtLaser;
    }

    void OnDisable()
    {
        //트랙 패드를 터치했을때 발생하는 이벤트의 연결해지
        trackedCtrl.PadTouched -= TrackPad;
        //트랙 패드의 터치가 해제됬을때 발생하는 이벤트의 연결해지
        trackedCtrl.PadUntouched -= ReleaseTrackPad;
        //트랙 패드를 클릭했을때 발생하는 이벤트의 연결해지
        trackedCtrl.PadClicked -= RayCastAtLaser;
    }

    //트랙 패드를 터치했을때 연결된 메소드
    void TrackPad(object sender, ClickedEventArgs e)
    {
        //진동(헵틱) 발생
        controller.TriggerHapticPulse(2000);
        Debug.Log("Pad is touched");

        //레이저를 활성화
        laser.enabled = true;
    }

    void ReleaseTrackPad(object sender, ClickedEventArgs e)
    {
        //레이저 비활성화
        laser.enabled = false;
    }

    void RayCastAtLaser(object sender, ClickedEventArgs e)
    {
        if (laser.enabled)
        {
            //레이캐스트로 이동할 위치 산출
            if (Physics.Raycast(tr.position, tr.forward, out hit, Mathf.Infinity, floorLayer))
            {
                MovePlayer(hit.point);
            }
        }
    }

    //이동로직 처리
    void MovePlayer(Vector3 pos)
    {
        //현재 높이값은 그대로 적용하기 위해 이동할 좌표를 수정
        Vector3 movePos = new Vector3(pos.x, playerTr.position.y, pos.z);
        playerTr.position = movePos;
    }
}
