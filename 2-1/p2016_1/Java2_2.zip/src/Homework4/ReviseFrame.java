package Homework4;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ReviseFrame extends JFrame implements ActionListener{
	private PrintWriter out;
	private BufferedReader in;
	private final String filename = "studentinfo.txt";
	private File file;
	
	JPanel panel_3,panel1_3,panel2_3,panel3_3,panel4_3,panel5_3,panel6_3;
	JLabel Namelabel3,IDlabel_3,PWlabel_3,ADRESSlabel3,NOTElabel3;
	JTextField Nametext3,IDtext_3,PWtext_3,ADRESStext3;
	JTextArea NOTEtext3;
	JButton Revisebutton2,Cancelbutton2;
	
	
	public ReviseFrame()
	{
		setSize(370,370);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		
		panel_3  = new JPanel();
		panel1_3  = new JPanel();
		panel1_3 .setPreferredSize(new Dimension(350, 30));
		panel1_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel2_3  = new JPanel();
		panel2_3 .setPreferredSize(new Dimension(350, 30));
		panel2_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel3_3  = new JPanel();
		panel3_3 .setPreferredSize(new Dimension(350, 30));
		panel3_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel4_3  = new JPanel();
		panel4_3 .setPreferredSize(new Dimension(350, 30));
		panel4_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel5_3  = new JPanel();
		panel5_3 .setPreferredSize(new Dimension(350, 100));
		panel5_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel6_3  = new JPanel();
		panel6_3 .setPreferredSize(new Dimension(163, 30));
		panel6_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		Namelabel3 = new JLabel("�̸�");
		Namelabel3.setPreferredSize(new Dimension(90, 23));
		Nametext3 = new JTextField(15);
		Nametext3.setEnabled(false);
		
		IDlabel_3 = new JLabel("���̵�");
		IDlabel_3.setPreferredSize(new Dimension(90, 23));
		IDtext_3 = new JTextField(15);
		IDtext_3.setEnabled(false);
		
		PWlabel_3 = new JLabel("�н�����");
		PWlabel_3.setPreferredSize(new Dimension(90, 23));
		PWtext_3 = new JTextField(15);
		PWtext_3.setEnabled(false);
		
		ADRESSlabel3 = new JLabel("�ּ�");
		ADRESSlabel3.setPreferredSize(new Dimension(90, 23));
		ADRESStext3 = new JTextField(15);
		ADRESStext3.setEnabled(true);
		
		NOTElabel3 = new JLabel("<html>�߰�����<br><br><br><br><br>");
		NOTElabel3.setPreferredSize(new Dimension(90, 80));
		NOTEtext3 = new JTextArea(5,15);
		NOTEtext3.setEnabled(true);
	
		Cancelbutton2 = new JButton("���");
		Cancelbutton2.setPreferredSize(new Dimension(75, 23));
		Cancelbutton2.addActionListener(this);
		

		Revisebutton2 = new JButton("����");
		Revisebutton2.setPreferredSize(new Dimension(75, 23));
		Revisebutton2.addActionListener(this);
		
		/* 
		�ؽ�Ʈ �ʵ� �ʱⰪ����(�α��ε� ���̵� ������ �ִ´�)
		Nametext3.setText();
		IDtext_3.setText();
		PWtext_3.setText();
		ADRESStext3.setText();
		NOTEtext3.setText();
		*/
		
		
		panel1_3.add(Namelabel3);
		panel1_3.add(Nametext3);
		panel2_3.add(IDlabel_3);
		panel2_3.add(IDtext_3);
		panel3_3.add(PWlabel_3);
		panel3_3.add(PWtext_3);
		panel4_3.add(ADRESSlabel3);
		panel4_3.add(ADRESStext3);
		panel5_3.add(NOTElabel3);
		panel5_3.add(NOTEtext3);
		panel6_3.add(Revisebutton2);
		panel6_3.add(Cancelbutton2);
	
	
		panel_3.add(panel1_3);
		panel_3.add(panel2_3);
		panel_3.add(panel3_3);
		panel_3.add(panel4_3);
		panel_3.add(panel5_3);
		panel_3.add(panel6_3);
		
		add(panel_3);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource() == Revisebutton2)
		{
			
			LoginFrame lf = new LoginFrame();
			System.out.println(" ���� ����� �����κ� �����۵� ��");
			setVisible(false);
			//���� �����??
			
		
		}
		
		if(e.getSource() == Cancelbutton2)
		{
			LoginSuccess ls = new LoginSuccess();
			setVisible(false);
		}
		
	}

}
