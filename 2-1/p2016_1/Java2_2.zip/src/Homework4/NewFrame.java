package Homework4;

public class NewFrame
{
	public static void main(String[] args)
	{
		LoginFrame lf = new LoginFrame();
	}


}
